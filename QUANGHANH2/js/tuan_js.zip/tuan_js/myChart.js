﻿
$(function () {
    var ldtt_list = ["LĐTT THEO DANH SÁCH"];
    var ldtt_nghi_dai = ["LĐTT NGHỈ DÀI"];
    var ldbq = ["LĐBQ ĐI LÀM"];
    var i = 1;
    $('.table_container').find('.total_ldtt').each(function () {
        ldtt_list[i] = $(this).text();
        i++;
    });
    i = 1;
    $('.table_container').find('.total_ldtt_nghi_dai').each(function () {
        ldtt_nghi_dai[i] = $(this).text();
        i++;
    });
    i = 1;
    $('.table_container').find('.ldbq_di_lam').each(function () {
        ldbq[i] = $(this).text();
        i++;
    });
    var a = c3.generate({
        bindto: "#data-color",
        size: { height: 800 },
        data: {
            columns: [
                ldtt_list,
                ldtt_nghi_dai,
                ldbq
            ],
            type: "bar",
            colors: { data1: "#4fc3f7", data2: "#2962FF" },
            color: function (a, o) { return o.id && "data3" === o.id ? d3.rgb(a).darker(o.value / 150) : a }
        },
        grid: { y: { show: !0 } }
    });
});